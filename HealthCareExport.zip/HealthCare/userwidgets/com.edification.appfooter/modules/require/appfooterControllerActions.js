define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchEnd defined for lblFooter **/
    AS_Label_b7781165c0f5468293c22a9386038123: function AS_Label_b7781165c0f5468293c22a9386038123(eventobject, x, y) {
        var self = this;
        self.view.flexCredits.isVisible = true;
        self.view.lblFooter.isVisible = false;
    },
    /** onClick defined for flexCredits **/
    AS_FlexContainer_gf1f028521a24b239c1972443f4583f9: function AS_FlexContainer_gf1f028521a24b239c1972443f4583f9(eventobject) {
        var self = this;
        self.view.flexCredits.isVisible = false;
        self.view.lblFooter.isVisible = true;
    }
});