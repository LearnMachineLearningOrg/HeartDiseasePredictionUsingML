define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onRowClick defined for segDiseasePredictions **/
    AS_Segment_id8550a531fd49819def2ee4d1d5edd2: function AS_Segment_id8550a531fd49819def2ee4d1d5edd2(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.navigateDiseasePredictionForm.call(this);
    }
});