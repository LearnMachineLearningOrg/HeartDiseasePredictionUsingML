define({ 

  //Type your controller code here 
  navigateDiseasePredictionForm : function () {
    if ("Heart disease prediction" === this.view.segDiseasePredictions.selectedRowItems[0].lblDisease) {
      var navigateToForm = new kony.mvc.Navigation("frmHeartDiseasePrediction");
      navigateToForm.navigate();   
    }  
  }
});