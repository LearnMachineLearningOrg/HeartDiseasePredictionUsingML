define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmHeartDiseasePrediction **/
    AS_Form_f97beaba6bdf474eafcd92f3298f8cc4: function AS_Form_f97beaba6bdf474eafcd92f3298f8cc4(eventobject) {
        var self = this;
        self.view.flexCriticalFactors.isVisible = true;
    },
    /** onClick defined for flexCriticalFactors **/
    AS_FlexContainer_b7afa29c01884de6b085e4cf39869383: function AS_FlexContainer_b7afa29c01884de6b085e4cf39869383(eventobject) {
        var self = this;
        self.view.flexCriticalFactors.isVisible = false;
    },
    /** onRowClick defined for segHeartDiseaseCriticalFactors **/
    AS_Segment_c1ac939c5b4b4e07bc0ddc208cd01d99: function AS_Segment_c1ac939c5b4b4e07bc0ddc208cd01d99(eventobject, sectionNumber, rowNumber) {
        var self = this;
        self.view.flexCriticalFactors.isVisible = false;
    },
    /** onClick defined for btnInput1 **/
    AS_Button_hef8628668134a70962a3283ca7f6bf9: function AS_Button_hef8628668134a70962a3283ca7f6bf9(eventobject) {
        var self = this;
        if (sknBtn1 === eventobject.skin) {
            sex = 1;
            eventobject.skin = sknBtn2;
            this.view.inputTwoOptions.btnInput2.skin = sknBtn1;
        } else if (sknBtn2 === eventobject.skin) {
            sex = -1;
            eventobject.skin = sknBtn1;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_f1c1efbbb94a40b3a98a9da89d644715: function AS_Button_f1c1efbbb94a40b3a98a9da89d644715(eventobject) {
        var self = this;
        if (sknBtn1 === eventobject.skin) {
            sex = 0;
            eventobject.skin = sknBtn2;
            this.view.inputTwoOptions.btnInput1.skin = sknBtn1;
        } else if (sknBtn2 === eventobject.skin) {
            sex = -1;
            eventobject.skin = sknBtn1;
        }
    },
    /** onClick defined for btnInput1 **/
    AS_Button_g66dc3dc5d574e30ba1526306594097d: function AS_Button_g66dc3dc5d574e30ba1526306594097d(eventobject) {
        var self = this;
        if (sknBtn1 === eventobject.skin) {
            fbs = 1;
            eventobject.skin = sknBtn2;
            this.view.inputTwoOptions1.btnInput2.skin = sknBtn1;
        } else if (sknBtn2 === eventobject.skin) {
            fbs = -1;
            eventobject.skin = sknBtn1;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_h291975d64814b18b703ed28dd2e3198: function AS_Button_h291975d64814b18b703ed28dd2e3198(eventobject) {
        var self = this;
        if (sknBtn1 === eventobject.skin) {
            fbs = 0;
            eventobject.skin = sknBtn2;
            this.view.inputTwoOptions1.btnInput1.skin = sknBtn1;
        } else if (sknBtn2 === eventobject.skin) {
            fbs = -1;
            eventobject.skin = sknBtn1;
        }
    },
    /** onClick defined for btnInput1 **/
    AS_Button_f344328ef4b34b96a0f22acf7bd2c5ea: function AS_Button_f344328ef4b34b96a0f22acf7bd2c5ea(eventobject) {
        var self = this;
        if (sknBtn1 === eventobject.skin) {
            exang = 1;
            eventobject.skin = sknBtn2;
            this.view.inputTwoOptions2.btnInput2.skin = sknBtn1;
        } else if (sknBtn2 === eventobject.skin) {
            exang = -1;
            eventobject.skin = sknBtn1;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_gdae899c9b7c4e3c89699779af486073: function AS_Button_gdae899c9b7c4e3c89699779af486073(eventobject) {
        var self = this;
        if (sknBtn1 === eventobject.skin) {
            exang = 0;
            eventobject.skin = sknBtn2;
            this.view.inputTwoOptions2.btnInput1.skin = sknBtn1;
        } else if (sknBtn2 === eventobject.skin) {
            exang = -1;
            eventobject.skin = sknBtn1;
        }
    },
    /** onClick defined for btnInput1 **/
    AS_Button_c21d1aded95d49bbbcfa61fbe6234a13: function AS_Button_c21d1aded95d49bbbcfa61fbe6234a13(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            restecg = 0;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions.btnInput2.skin = sknBtn4;
            this.view.inputThreeOptions.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            restecg = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_ad0134b7126c452bbd29a4c59f2f6739: function AS_Button_ad0134b7126c452bbd29a4c59f2f6739(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            restecg = 1;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            restecg = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput3 **/
    AS_Button_ad23291fdea74cb491540d979db794b8: function AS_Button_ad23291fdea74cb491540d979db794b8(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            restecg = 2;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions.btnInput2.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            restecg = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput1 **/
    AS_Button_ib015233a4e24fde8ee39b884d668138: function AS_Button_ib015233a4e24fde8ee39b884d668138(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            slope = 1;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions1.btnInput2.skin = sknBtn4;
            this.view.inputThreeOptions1.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            slope = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_d4dc994c86ea4f86a8c7a5edb3598535: function AS_Button_d4dc994c86ea4f86a8c7a5edb3598535(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            slope = 2;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions1.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions1.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            slope = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput3 **/
    AS_Button_a64f9c8174f54d14a57ac0af9d850013: function AS_Button_a64f9c8174f54d14a57ac0af9d850013(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            slope = 3;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions1.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions1.btnInput2.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            slope = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput1 **/
    AS_Button_c1f0032efb464a14897d91bead7986bf: function AS_Button_c1f0032efb464a14897d91bead7986bf(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            ca = 0;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions2.btnInput2.skin = sknBtn4;
            this.view.inputThreeOptions2.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            ca = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_gfc495503e9b456e88d4ed7bedeee147: function AS_Button_gfc495503e9b456e88d4ed7bedeee147(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            ca = 1;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions2.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions2.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            ca = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput3 **/
    AS_Button_h4891338ed834581af51fb7671c1a880: function AS_Button_h4891338ed834581af51fb7671c1a880(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            ca = 2;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions2.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions2.btnInput2.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            ca = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput1 **/
    AS_Button_f178535005d348c89a04e697be9a1829: function AS_Button_f178535005d348c89a04e697be9a1829(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            thal = 3;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions3.btnInput2.skin = sknBtn4;
            this.view.inputThreeOptions3.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            thal = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_e37dd221f5fb4e298c9532fa69ddd8b8: function AS_Button_e37dd221f5fb4e298c9532fa69ddd8b8(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            thal = 6;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions3.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions3.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            thal = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput3 **/
    AS_Button_hc851c73de134d3e82541dfab8eca639: function AS_Button_hc851c73de134d3e82541dfab8eca639(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            thal = 7;
            eventobject.skin = sknBtn5;
            this.view.inputThreeOptions3.btnInput1.skin = sknBtn4;
            this.view.inputThreeOptions3.btnInput2.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            thal = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput1 **/
    AS_Button_ebeaa4ea88d7467d965fa6dacc5e4437: function AS_Button_ebeaa4ea88d7467d965fa6dacc5e4437(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            cp = 1;
            eventobject.skin = sknBtn5;
            this.view.inputFourOptions.btnInput2.skin = sknBtn4;
            this.view.inputFourOptions.btnInput3.skin = sknBtn4;
            this.view.inputFourOptions.btnInput4.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            cp = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput2 **/
    AS_Button_cecd04c6bcc44e568a6ed56891057f87: function AS_Button_cecd04c6bcc44e568a6ed56891057f87(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            cp = 2;
            eventobject.skin = sknBtn5;
            this.view.inputFourOptions.btnInput1.skin = sknBtn4;
            this.view.inputFourOptions.btnInput3.skin = sknBtn4;
            this.view.inputFourOptions.btnInput4.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            cp = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput3 **/
    AS_Button_i407472123564e21a4b6fc955052b960: function AS_Button_i407472123564e21a4b6fc955052b960(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            cp = 3;
            eventobject.skin = sknBtn5;
            this.view.inputFourOptions.btnInput1.skin = sknBtn4;
            this.view.inputFourOptions.btnInput2.skin = sknBtn4;
            this.view.inputFourOptions.btnInput4.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            cp = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for btnInput4 **/
    AS_Button_e8833812ba3b4a7bb84d0a1883378706: function AS_Button_e8833812ba3b4a7bb84d0a1883378706(eventobject) {
        var self = this;
        if (sknBtn4 === eventobject.skin) {
            cp = 4;
            eventobject.skin = sknBtn5;
            this.view.inputFourOptions.btnInput1.skin = sknBtn4;
            this.view.inputFourOptions.btnInput2.skin = sknBtn4;
            this.view.inputFourOptions.btnInput3.skin = sknBtn4;
        } else if (sknBtn5 === eventobject.skin) {
            cp = -1;
            eventobject.skin = sknBtn4;
        }
    },
    /** onClick defined for flexPredictionResults **/
    AS_FlexContainer_hd5a591451d646edb5496bff22f75501: function AS_FlexContainer_hd5a591451d646edb5496bff22f75501(eventobject) {
        var self = this;
        self.view.flexPredictionResults.isVisible = false;
    },
    /** onClick defined for btnSubmit **/
    AS_Button_c5bb53ace4844eee95301b9c3ee73e5c: function AS_Button_c5bb53ace4844eee95301b9c3ee73e5c(eventobject) {
        var self = this;
        return self.validateInputs.call(this);
    }
});