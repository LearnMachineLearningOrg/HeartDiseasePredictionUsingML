define({ 

  //Type your controller code here 
  predictHeartDisease: function () {
    showProgressIndicator("Predicting heart disease ...");

    var serviceID = "HeartDiseasesPrediction";
    var integrationObj = KNYMobileFabric.getIntegrationService(serviceID);

    var operationID = "predictHeartDisease";
    var predictHeartDiseaseHeaders = {};
    var predictHeartDiseaseInputparam = {};
    predictHeartDiseaseInputparam.age = this.view.inputTextBox.tbxInputValue.text;
    predictHeartDiseaseInputparam.trestbps = this.view.inputTextBox1.tbxInputValue.text;
    predictHeartDiseaseInputparam.chol = this.view.inputTextBox2.tbxInputValue.text;
    predictHeartDiseaseInputparam.thalach = this.view.inputTextBox3.tbxInputValue.text;
    predictHeartDiseaseInputparam.oldpeak = this.view.inputTextBox4.tbxInputValue.text;
    predictHeartDiseaseInputparam.sex = sex;
    predictHeartDiseaseInputparam.fbs = fbs;
    predictHeartDiseaseInputparam.exang = exang;
    predictHeartDiseaseInputparam.restecg = restecg;
    predictHeartDiseaseInputparam.slope = slope;
    predictHeartDiseaseInputparam.ca = ca;
    predictHeartDiseaseInputparam.thal = thal;
    predictHeartDiseaseInputparam.cp = cp;
    predictHeartDiseaseInputparam.target = 0;

    kony.print("Inputs for predicting heart disease: "+JSON.stringify(predictHeartDiseaseInputparam));
    integrationObj.invokeOperation(operationID, predictHeartDiseaseHeaders, predictHeartDiseaseInputparam, this.predictHeartDiseaseSuccess.bind(this), this.predictHeartDiseaseFailure.bind(this));

  },

  predictHeartDiseaseSuccess: function (response) {
    dismissLoadingIndicator();
    kony.print ("*** Entering into predictHeartDiseaseSuccess ***");
    kony.print("Response of heart disease prediction: "+JSON.stringify(response));
    if (response.opstatus === 0) {
      if (response.prediction === "1") {
        this.view.lblPredictionResults.text = "Angiographic disease status: Greater than 50% diameter narrowing in any of the major vessel. Please consult a cardiologist.";
      } else if (response.prediction === "0") {
        this.view.lblPredictionResults.text = "Angiographic disease status: Less than 50% diameter narrowing in any of the major vessel.";
      }
    }else {
      this.view.lblPredictionResults.text = "Error occured while predicting the heart disease. Please try again after some time.";
    }
    this.view.flexPredictionResults.setVisibility(true);
    kony.print("*** Exiting out of predictHeartDiseaseSuccess ***");
  },

  predictHeartDiseaseFailure: function (error) {
    dismissLoadingIndicator();
    kony.print ("*** Entering into predictHeartDiseaseFailure ***");
    kony.print("Error occured while predicting the heart disease.: "+JSON.stringify(error));
    this.view.lblPredictionResults.text = "Error occured while predicting the heart disease. Please try again after some time.";
    this.view.flexPredictionResults.setVisibility(true);
    kony.print("*** Exiting out of predictHeartDiseaseFailure ***");
  },
  
  validateInputs: function () {
    if (sex === -1 || fbs === -1 || exang === -1 || restecg === -1 || slope === -1 || ca === -1 || thal === -1 || cp === -1) {
      alert("Please provide inputs to all the critical factors, only than we can predict the heart disease.");
    } else {
      this.predictHeartDisease();
    }
  }

});