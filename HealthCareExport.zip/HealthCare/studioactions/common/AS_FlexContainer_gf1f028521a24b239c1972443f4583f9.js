function AS_FlexContainer_gf1f028521a24b239c1972443f4583f9(eventobject) {
    var self = this;
    self.view.flexCredits.isVisible = false;
    self.view.lblFooter.isVisible = true;
}