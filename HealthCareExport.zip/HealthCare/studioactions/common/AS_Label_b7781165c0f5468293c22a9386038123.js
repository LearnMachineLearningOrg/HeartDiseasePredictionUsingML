function AS_Label_b7781165c0f5468293c22a9386038123(eventobject, x, y) {
    var self = this;
    self.view.flexCredits.isVisible = true;
    self.view.lblFooter.isVisible = false;
}